package com.tns.dayfive.interfacedemo;


//parent interface
public interface InterfaceDemo {

	public void print();
	
	
}
