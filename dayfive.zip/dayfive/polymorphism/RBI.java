package com.tns.dayfive.polymorphism;


//parent
public class RBI {
	
	public float getRateOfInterest() {
		return 6.9f;
	}
}


