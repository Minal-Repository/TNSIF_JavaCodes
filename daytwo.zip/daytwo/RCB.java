package com.tns.daytwo;

public class RCB {

	public static void main(String[] args) {
		
		//creation of object
		
		RcbDemo team = new RcbDemo(); //
		team.setPlayerName("Virat Kohli");
		team.setAge(36);
		team.setJersyNo(18);
		System.out.println(team);
		

	}

}
