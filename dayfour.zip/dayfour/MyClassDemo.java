package com.tns.dayfour;

public class MyClassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MyClass c1 = new MyClass();
		
		System.out.println(c1);
		c1.display();
		
		MyClass c2 = new MyClass();
		
		System.out.println(c2);
		c2.display();
		
		
		MyClass c3 = new MyClass();
		
		System.out.println(c3);
		c3.display();
		
	}

}
