package com.tns.dayfour;

public class FinalVariable {

	final int x = 100;
	
	//final static int y;
	
	//final static int z = 10;
	
	
	void change()
	{
		x = 30;
	//	y = 20;
	}
	
	
}
